
<h1>Building the clone of ‘Amazon Prime Video’</h1>

<p>Hello reader, Surajit this side welcomes you to this blog post. Let me introduce you to the platform first, so “Amazon Prime Video” is an entertainment website , I am creating this blog to share My experience of working on a project assigned to me by our Masai School and how I’m manage project work within six days. Thanks to Masai School for giving us an opportunity to build a project. It was really great experience.</p>
<br/>
<h3>Landing Page : </h3>
<img src="https://raw.githubusercontent.com/Surajit-Dhar/Photos/main/Screenshot%20(81).png" alt="project pik">

<h3>TECHNOLOGY STACK WE USED</h3>
<p>Here we are creating a clone of Amazon Prime Video website, giving structure and layouts with the help of HTML, styling is done using CSS and functionality using JavaScript and Local Storage.</p>

<h3>STARTING THE PROJECT</h3>
<p>First day I’m started by going through the website, understanding the structure and layouts.
I divided about the parts of the website Day wish, I should build and how Considering the time constraint.</p>
<br/>
<h3>SignUp Page : </h3>
<img src="https://raw.githubusercontent.com/Surajit-Dhar/Photos/main/Screenshot%20(82).png" alt="project pik">

<h3>CHALLENGES</h3>
1.If you are working on a big and full-stack project, there are always some challenges waiting for you, with me too it was nothing different.
2.The most crucial part of any big website, we faced a bit problem at some phases, but in the end, we learned some new things and resolved all issues.
3.Main problems I’m Faced set responsiveness of home pages, one side right and another side is wrong, but spent more time and finally achieved.
4.Last but not the least, I had to complete the project in a span of 6 days, so there was a pressure that , but all dedication and hard work we managed to complete it in just 5 days, surprised? but yes that is the truth.
<br/>
Now let me take a pause and thank you as well for being with me till here, yes this smile that you are having right now, I care for that. Now let me showcase my project to you.
<br/>
<h3>Movie Page : </h3>
<img src="https://raw.githubusercontent.com/Surajit-Dhar/Photos/main/Screenshot%20(70).png" alt="project pik">

<h4>These were just some of the parts, you can go through the whole website by https://dreamy-shockley-6f2771.netlify.app</h4>
<h4>Also the public GitHub repo link is here — https://github.com/Surajit-Dhar/Amazon-Prime-Video.git</h4>
<br/>
<h3>MovieList with sorting : </h3>
<img src="https://raw.githubusercontent.com/Surajit-Dhar/Photos/main/Screenshot%20(71).png" alt="project pik">
<h3>Major takeaways from the Project<h3>
<ul>
<li>There is a lot of learning to take when you work on a individual project, and it is even more if you are working for the very first time.</li>
  <li>Learning GIT</li>
  <li>Getting industry like experience</li>
  <li>Work within the time constraints</li>
<p>If you are still here listening to me, I am so glad and I thank you with all my heart, Before going I would like you to rate our project and give suggestions in the comments, I would love to have them. Once again thank you and I will meet again after a month with some other exciting project.</P>
  <h4>Thank You.</h4>
